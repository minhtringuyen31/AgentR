"""Test E2E service bằng TestClient — mô phỏng luồng thật của client.

    python -m risk_agent.test_service
"""
from __future__ import annotations

import os
import time

# dùng checkpoint riêng cho test
os.environ.setdefault("PYTEST", "1")

from fastapi.testclient import TestClient
from .service import app

SAMPLE_EMAIL = """\
From: fraud-ops@company.vn
Subject: [URGENT] Suspicious high-value night transactions
3 cases (c001, c002, c003) high-value night txns from reused devices.
Analyze last 90 days, propose detection rule.
"""


def _wait_status(client, run_id, target, timeout=15.0):
    """Poll đến khi status == target (background task chạy xong)."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = client.get(f"/runs/{run_id}").json()
        if r["status"] == target:
            return r
        time.sleep(0.2)
    raise TimeoutError(f"run {run_id} không đạt status {target}, "
                       f"hiện tại: {r['status']}")


def main():
    client = TestClient(app)

    print("health:", client.get("/health").json())

    # 1) Trigger run (threshold thực tế -> pass nhanh)
    resp = client.post("/runs", json={
        "source_type": "email",
        "raw_input": SAMPLE_EMAIL,
        "min_precision": 0.80,
        "min_recall": 0.60,
        "max_iterations": 6,
    })
    assert resp.status_code == 202, resp.text
    run_id = resp.json()["run_id"]
    print(f"\n1. Created run {run_id} -> status=running")

    # 2) Poll đến khi chờ review
    r = _wait_status(client, run_id, "awaiting_review")
    print(f"2. Run paused -> awaiting_review")
    print(f"   pattern : {r['pattern']}")
    print(f"   metrics : P={r['metrics']['precision']} "
          f"R={r['metrics']['recall']} F1={r['metrics']['f1']}")
    print(f"   route   : {r['route']}  (iteration {r['iteration_count']})")

    # 3) Approve -> resume
    resp = client.post(f"/runs/{run_id}/review",
                       json={"decision": "approve", "reviewer": "minhtri"})
    assert resp.status_code == 200, resp.text
    print(f"\n3. Approved -> resuming")

    # 4) Poll đến completed
    r = _wait_status(client, run_id, "completed")
    print(f"4. Run completed")
    print(f"   recommendation: {r['recommendation']}")
    print(f"   rule SQL: {r['sql'][:70]}...")

    # 5) List runs
    runs = client.get("/runs").json()
    print(f"\n5. Total runs in store: {len(runs)}")

    # 6) Test reject branch với threshold cao (escalate)
    print("\n6. Testing reject branch (high threshold)")
    resp = client.post("/runs", json={
        "source_type": "postmortem",
        "raw_input": SAMPLE_EMAIL,
        "min_precision": 0.80,
        "min_recall": 0.95,   # cao -> escalate
        "max_iterations": 4,
    })
    rid2 = resp.json()["run_id"]
    r = _wait_status(client, rid2, "awaiting_review")
    print(f"   paused, route={r['route']} after {r['iteration_count']} iters")
    client.post(f"/runs/{rid2}/review",
                json={"decision": "reject", "reviewer": "minhtri"})
    r = _wait_status(client, rid2, "completed")
    print(f"   final: {r['recommendation']}")

    print("\n=== ALL TESTS PASSED ===")


if __name__ == "__main__":
    main()
