"""FastAPI service cho Risk Analysis Agent.

Endpoints:
  POST /runs                     - tạo run mới từ trigger (chạy nền đến interrupt)
  GET  /runs/{run_id}            - trạng thái + report hiện tại
  POST /runs/{run_id}/review     - approve/reject -> resume agent
  GET  /runs                     - list runs
  POST /triggers/email           - webhook nhận email fraud report
  POST /triggers/postmortem      - webhook nhận post-mortem DB event

Chạy:
  uvicorn risk_agent.service:app --reload
Docs tự động tại http://localhost:8000/docs
"""
from __future__ import annotations

import sqlite3
import uuid
from contextlib import asynccontextmanager
from enum import Enum
from typing import Optional

from fastapi import FastAPI, BackgroundTasks, HTTPException
from pydantic import BaseModel, Field

from langgraph.checkpoint.sqlite import SqliteSaver

from .graph import build_graph
from .state import ThresholdConfig


# ---------- checkpointer + graph (persistent, dùng chung) ----------

_conn = sqlite3.connect("checkpoints.db", check_same_thread=False)
CHECKPOINTER = SqliteSaver(_conn)
APP_GRAPH = build_graph(checkpointer=CHECKPOINTER)


# ---------- API models ----------

class SourceType(str, Enum):
    email = "email"
    postmortem = "postmortem"


class RunStatus(str, Enum):
    running = "running"
    awaiting_review = "awaiting_review"
    completed = "completed"
    failed = "failed"


class CreateRunRequest(BaseModel):
    source_type: SourceType
    raw_input: str = Field(..., description="Email text hoặc post-mortem record JSON")
    min_precision: float = 0.80
    min_recall: float = 0.60
    max_iterations: int = 6


class ReviewRequest(BaseModel):
    decision: str = Field(..., pattern="^(approve|reject)$")
    reviewer: str


class MetricsOut(BaseModel):
    precision: float
    recall: float
    f1: float
    hit_count: int
    total_fraud: int
    total_flagged: int


class RunOut(BaseModel):
    run_id: str
    status: RunStatus
    iteration_count: Optional[int] = None
    pattern: Optional[str] = None
    metrics: Optional[MetricsOut] = None
    sql: Optional[str] = None
    recommendation: Optional[str] = None
    route: Optional[str] = None


# ---------- helpers ----------

def _cfg(run_id: str) -> dict:
    return {"configurable": {"thread_id": run_id}}


def _run_until_interrupt(run_id: str, initial: dict) -> None:
    """Background task: chạy agent đến khi hit interrupt hoặc kết thúc."""
    try:
        for _ in APP_GRAPH.stream(initial, _cfg(run_id)):
            pass
    except Exception as e:  # noqa: BLE001
        # production: log + set error state. Ở đây giữ đơn giản.
        print(f"[run {run_id}] error: {e}")


def _resume(run_id: str) -> None:
    for _ in APP_GRAPH.stream(None, _cfg(run_id)):
        pass


def _snapshot_to_out(run_id: str) -> RunOut:
    snap = APP_GRAPH.get_state(_cfg(run_id))
    if not snap.values:
        raise HTTPException(404, f"Run {run_id} không tồn tại")

    v = snap.values
    report = v.get("final_report")

    # xác định status từ vị trí graph
    if snap.next == ("human_review",):
        status = RunStatus.awaiting_review
    elif not snap.next:
        status = RunStatus.completed
    else:
        status = RunStatus.running

    out = RunOut(run_id=run_id, status=status,
                 iteration_count=v.get("iteration_count"),
                 route=v.get("route"))
    if report:
        out.pattern = report["pattern"]["description"]
        out.metrics = MetricsOut(**report["metrics"])
        out.sql = report["sql"]
        out.recommendation = report["recommendation"]
    return out


# ---------- app ----------

@asynccontextmanager
async def lifespan(app: FastAPI):
    from . import mock_data
    mock_data.ensure_data()   # đảm bảo có data local
    yield


app = FastAPI(title="Risk Analysis Agent", version="0.1.0", lifespan=lifespan)


@app.post("/runs", response_model=RunOut, status_code=202)
def create_run(req: CreateRunRequest, bg: BackgroundTasks):
    run_id = str(uuid.uuid4())[:8]
    initial = {
        "run_id": run_id,
        "source_type": req.source_type.value,
        "raw_input": req.raw_input,
        "threshold_config": ThresholdConfig(
            min_precision=req.min_precision,
            min_recall=req.min_recall,
            max_iterations=req.max_iterations,
        ).model_dump(),
    }
    bg.add_task(_run_until_interrupt, run_id, initial)
    return RunOut(run_id=run_id, status=RunStatus.running)


@app.get("/runs/{run_id}", response_model=RunOut)
def get_run(run_id: str):
    return _snapshot_to_out(run_id)


@app.post("/runs/{run_id}/review", response_model=RunOut)
def review_run(run_id: str, req: ReviewRequest, bg: BackgroundTasks):
    snap = APP_GRAPH.get_state(_cfg(run_id))
    if not snap.values:
        raise HTTPException(404, f"Run {run_id} không tồn tại")
    if snap.next != ("human_review",):
        raise HTTPException(409, "Run không ở trạng thái chờ review")

    APP_GRAPH.update_state(_cfg(run_id), {
        "review_decision": req.decision,
        "approved_by": req.reviewer,
    })
    bg.add_task(_resume, run_id)
    return RunOut(run_id=run_id, status=RunStatus.running)


@app.get("/runs", response_model=list[str])
def list_runs():
    # SqliteSaver: lấy distinct thread_id từ checkpoints
    rows = _conn.execute(
        "SELECT DISTINCT thread_id FROM checkpoints ORDER BY thread_id"
    ).fetchall()
    return [r[0] for r in rows]


@app.post("/triggers/email", response_model=RunOut, status_code=202)
def trigger_email(req: CreateRunRequest, bg: BackgroundTasks):
    """Webhook cho email listener — alias của /runs với source=email."""
    req.source_type = SourceType.email
    return create_run(req, bg)


@app.post("/triggers/postmortem", response_model=RunOut, status_code=202)
def trigger_postmortem(req: CreateRunRequest, bg: BackgroundTasks):
    req.source_type = SourceType.postmortem
    return create_run(req, bg)


@app.get("/health")
def health():
    return {"status": "ok"}
