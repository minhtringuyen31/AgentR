"""Lắp ráp LangGraph StateGraph.

Topology:
  START -> ingest -> fetch_data -> hypothesis -> sql_gen -> metrics -> router
  router --retry--> hypothesis        (loop)
  router --escalate--> human_review
  router --pass--> human_review
  human_review -> [INTERRUPT] -> policy_output -> END
"""
from __future__ import annotations

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

from .state import AgentState
from . import nodes


def build_graph(checkpointer=None):
    g = StateGraph(AgentState)

    g.add_node("ingest", nodes.ingest_node)
    g.add_node("fetch_data", nodes.fetch_data_node)
    g.add_node("hypothesis", nodes.hypothesis_node)
    g.add_node("sql_gen", nodes.sql_gen_node)
    g.add_node("metrics", nodes.metrics_node)
    g.add_node("router", nodes.router_node)
    g.add_node("human_review", nodes.human_review_node)
    g.add_node("policy_output", nodes.policy_output_node)

    g.add_edge(START, "ingest")
    g.add_edge("ingest", "fetch_data")
    g.add_edge("fetch_data", "hypothesis")
    g.add_edge("hypothesis", "sql_gen")
    g.add_edge("sql_gen", "metrics")
    g.add_edge("metrics", "router")

    # conditional edge dựa trên state["route"]
    g.add_conditional_edges(
        "router",
        nodes.route_decision,
        {
            "retry": "hypothesis",       # vòng lặp pattern discovery
            "pass": "human_review",
            "escalate": "human_review",
        },
    )

    g.add_edge("human_review", "policy_output")
    g.add_edge("policy_output", END)

    cp = checkpointer or MemorySaver()
    # pause TRƯỚC human_review để chờ strategist approve/reject
    return g.compile(checkpointer=cp, interrupt_before=["human_review"])
