"""LLM abstraction layer.

Mặc định dùng MockLLM (chạy không cần API key, deterministic) để test loop.
Đặt biến môi trường ANTHROPIC_API_KEY và USE_REAL_LLM=1 để chuyển sang Claude thật.
"""
from __future__ import annotations

import json
import os
import re


class BaseLLM:
    def complete_json(self, system: str, user: str) -> dict:
        raise NotImplementedError


class MockLLM(BaseLLM):
    """LLM giả lập — đủ thông minh để demo loop pattern discovery.

    Stateless: đọc iteration từ prompt nên an toàn với concurrent runs.
    Mô phỏng: pattern hẹp trước (precision cao recall thấp), nới dần sau.
    """

    def complete_json(self, system: str, user: str) -> dict:
        # ingest_node
        if "extract structured context" in system:
            return {
                "case_ids": ["c001", "c002", "c003"],
                "fraud_type": "device_reuse_high_amount",
                "severity": "high",
                "time_hint": "last 90 days",
                "raw_summary": "Multiple high-value night transactions from reused devices",
            }

        # hypothesis_node — pattern nới dần qua iteration.
        # Đọc iteration từ prompt (stateless) để an toàn với concurrent runs.
        if "propose a fraud pattern" in system:
            iteration = _extract_num(user, "iteration") or 1
            patterns = [
                {
                    "description": "Heavily-reused device + amount > 10M + night (<5h)",
                    "signal_columns": ["device_id", "amount", "hour"],
                    "rationale": "Strictest first to maximize precision",
                    "expected_precision": 0.95, "expected_recall": 0.30,
                    "_reuse": 15, "_amount": 10_000_000, "_hour": 5,
                },
                {
                    "description": "Heavily-reused device + amount > 5M + night (<5h)",
                    "signal_columns": ["device_id", "amount", "hour"],
                    "rationale": "Loosen amount threshold to recover recall",
                    "expected_precision": 0.85, "expected_recall": 0.65,
                    "_reuse": 15, "_amount": 5_000_000, "_hour": 5,
                },
                {
                    "description": "Reused device (>10) + amount > 5M + early (<6h)",
                    "signal_columns": ["device_id", "amount", "hour"],
                    "rationale": "Widen reuse and hour window for more recall",
                    "expected_precision": 0.82, "expected_recall": 0.72,
                    "_reuse": 10, "_amount": 5_000_000, "_hour": 6,
                },
            ]
            idx = min(iteration - 1, len(patterns) - 1)
            return patterns[idx]

        # sql_gen_node
        if "Translate the pattern into a single SQL" in system:
            reuse = _extract_num(user, "reuse") or 15
            amount = _extract_num(user, "amount") or 5_000_000
            hour = _extract_num(user, "hour") or 5
            return {
                "sql": (
                    "SELECT txn_id FROM transactions "
                    "WHERE device_id IN ("
                    "  SELECT device_id FROM transactions "
                    f"  GROUP BY device_id HAVING COUNT(*) > {reuse}"
                    f") AND amount > {amount} AND hour < {hour}"
                )
            }

        return {}


class ClaudeLLM(BaseLLM):
    """Claude API thật. Cần `pip install anthropic` + ANTHROPIC_API_KEY."""

    def __init__(self, model: str = "claude-3-5-sonnet-20241022", thinking: bool = False):
        from anthropic import Anthropic
        self.client = Anthropic()
        self.model = model
        self.thinking = thinking

    def complete_json(self, system: str, user: str) -> dict:
        kwargs = dict(
            model=self.model,
            max_tokens=2000,
            system=system + "\n\nRespond with ONLY valid JSON, no markdown, no preamble.",
            messages=[{"role": "user", "content": user}],
        )
        if self.thinking:
            kwargs["thinking"] = {"type": "enabled", "budget_tokens": 4000}
            kwargs["max_tokens"] = 6000
        resp = self.client.messages.create(**kwargs)
        text = "".join(b.text for b in resp.content if b.type == "text")
        text = re.sub(r"```json|```", "", text).strip()
        return json.loads(text)


def _extract(text: str, key: str) -> str | None:
    m = re.search(rf'"{key}"\s*:\s*"([^"]*)"', text)
    return m.group(1) if m else None


def _extract_num(text: str, key: str) -> int | None:
    m = re.search(rf'"_{key}"\s*:\s*(\d+)', text)
    return int(m.group(1)) if m else None


def get_llm(thinking: bool = False) -> BaseLLM:
    if os.getenv("USE_REAL_LLM") == "1":
        return ClaudeLLM(thinking=thinking)
    return MockLLM()
