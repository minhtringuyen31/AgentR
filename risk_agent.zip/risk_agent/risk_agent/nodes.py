"""Node functions cho LangGraph.

Mỗi node: (state) -> dict update. LangGraph merge update vào state.
LLM nodes gọi llm.get_llm(); tool nodes gọi tools.py.
"""
from __future__ import annotations

from . import tools
from .llm import get_llm
from .state import (
    AgentState, FraudContext, PatternHypothesis, MetricsResult,
    ThresholdConfig, PatternReport,
)


# ---------- LLM node: ingest ----------

def ingest_node(state: AgentState) -> dict:
    llm = get_llm()
    system = (
        "You are a fraud-report parser. Read the raw report and "
        "extract structured context: case ids, fraud type, severity, time hint."
    )
    user = f"Source: {state['source_type']}\n\nRaw report:\n{state['raw_input']}"
    ctx = FraudContext(**llm.complete_json(system, user))
    return {
        "fraud_context": ctx.model_dump(),
        "case_ids": ctx.case_ids,
        "iteration_count": 0,
        "hypotheses": [],
    }


# ---------- Tool node: fetch data ----------

def fetch_data_node(state: AgentState) -> dict:
    schema, sample = tools.get_schema_and_sample()
    return {
        "data_ref": "transactions",
        "data_schema": schema,
        "sample_rows": sample,
    }


# ---------- LLM node: hypothesis (core reasoning) ----------

def hypothesis_node(state: AgentState) -> dict:
    llm = get_llm(thinking=True)  # extended thinking cho bước reasoning chính
    prev_metrics = state.get("metrics")
    prev_note = ""
    if prev_metrics:
        prev_note = (
            f"\n\nPrevious attempt metrics: precision={prev_metrics['precision']}, "
            f"recall={prev_metrics['recall']}. Adjust the pattern to improve "
            f"whichever metric is below target."
        )
    system = (
        "You are a fraud risk strategist. Given transaction schema, sample data, "
        "and fraud context, propose a fraud pattern (a rule) that could identify "
        "fraudulent transactions. Output: description, signal_columns, rationale, "
        "expected_precision, expected_recall."
    )
    user = (
        f'"_iteration": {state.get("iteration_count", 0) + 1}\n'
        f"Fraud context: {state['fraud_context']}\n"
        f"Schema: {state['data_schema']}\n"
        f"Sample rows: {state['sample_rows'][:5]}"
        f"{prev_note}"
    )
    pattern = PatternHypothesis(**llm.complete_json(system, user))
    return {
        "current_pattern": pattern.model_dump(),
        "hypotheses": [pattern.model_dump()],   # Annotated[list, add] -> append
    }


# ---------- LLM + tool node: sql_gen ----------

def sql_gen_node(state: AgentState) -> dict:
    llm = get_llm()
    system = (
        "Translate the pattern into a single SQL SELECT query on the "
        "'transactions' table returning txn_id. Use the signal columns. "
        "Output: { \"sql\": \"...\" }."
    )
    # truyền sql_filter hint để mock LLM bám theo; LLM thật tự suy ra từ pattern
    pattern = state["current_pattern"]
    user = (
        f"Pattern: {pattern['description']}\n"
        f"Signal columns: {pattern['signal_columns']}\n"
        f'"_reuse": {pattern.get("reuse") or 15}, '
        f'"_amount": {pattern.get("amount") or 5000000}, '
        f'"_hour": {pattern.get("hour") or 5}\n'
        f"Schema: {state['data_schema']}"
    )
    sql = llm.complete_json(system, user)["sql"]
    sql = tools.validate_sql(sql)
    matched = tools.warehouse_query(sql)
    return {
        "current_sql": sql,
        "matched_case_ids": matched["txn_id"].tolist(),
    }


# ---------- Tool node: metrics ----------

def metrics_node(state: AgentState) -> dict:
    m = tools.compute_metrics(state["matched_case_ids"])
    return {
        "metrics": m,
        "iteration_count": state["iteration_count"] + 1,
    }


# ---------- Control: router (conditional edge) ----------

def router_node(state: AgentState) -> dict:
    """Tính route + build report (để report sẵn sàng trước interrupt)."""
    cfg = ThresholdConfig(**state["threshold_config"])
    m = state["metrics"]
    passed = m["precision"] >= cfg.min_precision and m["recall"] >= cfg.min_recall

    if passed:
        route = "pass"
    elif state["iteration_count"] >= cfg.max_iterations:
        route = "escalate"
    else:
        route = "retry"

    update = {"route": route}

    # Khi sắp dừng loop (pass/escalate), build report ngay để
    # snapshot tại interrupt đã có final_report cho strategist xem.
    if route in ("pass", "escalate"):
        report = PatternReport(
            pattern=PatternHypothesis(**state["current_pattern"]),
            sql=state["current_sql"],
            metrics=MetricsResult(**m),
            iteration_count=state["iteration_count"],
            iteration_history=state["hypotheses"],
            recommendation="Deploy as fraud rule" if route == "pass"
                           else "Escalate — threshold not met after max iterations",
        )
        update["final_report"] = report.model_dump()
    return update


def route_decision(state: AgentState) -> str:
    """Edge function — LangGraph dùng giá trị trả về để chọn nhánh."""
    return state["route"]


# ---------- Human-in-the-loop ----------

def human_review_node(state: AgentState) -> dict:
    """Notify strategist. interrupt_before đã pause TRƯỚC node này;
    report đã được build ở router_node nên snapshot có sẵn để review."""
    report = state["final_report"]
    tools.notify_strategist(
        f"{report['pattern']['description']}\n"
        f"precision={report['metrics']['precision']} "
        f"recall={report['metrics']['recall']} f1={report['metrics']['f1']}\n"
        f"SQL: {report['sql']}"
    )
    return {}


def policy_output_node(state: AgentState) -> dict:
    """Compile output cuối. Production: push RuleJSON vào config-service."""
    decision = state.get("review_decision", "approve")
    report = state["final_report"]
    if decision == "approve":
        rule_json = {
            "rule_name": f"fraud_{state['fraud_context']['fraud_type']}",
            "sql_predicate": report["sql"],
            "metrics": report["metrics"],
            "status": "approved",
            "approved_by": state.get("approved_by", "unknown"),
        }
        report["recommendation"] = f"APPROVED — rule ready: {rule_json['rule_name']}"
    else:
        report["recommendation"] = "REJECTED by strategist"
    return {"final_report": report}
