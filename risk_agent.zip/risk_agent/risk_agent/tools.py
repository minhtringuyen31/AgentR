"""Tools — đơn vị thực thi deterministic, không phải LLM.

Đây là lớp ranh giới với external systems. Production chỉ cần đổi
implementation bên trong, signature giữ nguyên.
"""
from __future__ import annotations

import re

import pandas as pd

from . import mock_data


# ---------- SQL safety ----------

_FORBIDDEN = re.compile(r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE)\b", re.I)


class UnsafeSQLError(Exception):
    pass


def validate_sql(sql: str) -> str:
    """Chặn SQL ghi dữ liệu — agent chỉ được phép SELECT.

    Đây là lớp bảo vệ tối thiểu khi cho LLM tự sinh SQL chạy trên warehouse.
    Production nên thêm: EXPLAIN cost check, row limit, timeout.
    """
    if _FORBIDDEN.search(sql):
        raise UnsafeSQLError(f"SQL chứa lệnh ghi bị cấm: {sql[:80]}")
    if sql.count(";") > 1:
        raise UnsafeSQLError("Multiple statements không được phép")
    return sql


# ---------- Warehouse ----------

def warehouse_query(sql: str) -> pd.DataFrame:
    """Chạy SELECT trên warehouse. Local = DuckDB, prod = BigQuery/Spark."""
    validate_sql(sql)
    return mock_data.query(sql)


def get_schema_and_sample(n: int = 20) -> tuple[dict, list[dict]]:
    """Lấy schema + sample rows để feed vào LLM context (không load full data)."""
    df = mock_data.query("SELECT * FROM transactions LIMIT 1000")
    schema = {col: str(dtype) for col, dtype in df.dtypes.items()}
    sample = df.head(n).to_dict(orient="records")
    return schema, sample


# ---------- Metrics ----------

def compute_metrics(matched_case_ids: list[str]) -> dict:
    """Tính precision/recall so với ground-truth label trong warehouse.

    Ground truth ở đây là cột is_fraud. Production: join với post-mortem DB
    chứa confirmed fraud cases.
    """
    all_df = mock_data.query("SELECT txn_id, is_fraud FROM transactions")
    truth = set(all_df[all_df.is_fraud == 1].txn_id)
    flagged = set(matched_case_ids)

    tp = len(flagged & truth)
    fp = len(flagged - truth)
    fn = len(truth - flagged)

    precision = tp / (tp + fp) if (tp + fp) else 0.0
    recall = tp / (tp + fn) if (tp + fn) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0

    return {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "hit_count": tp,
        "total_fraud": len(truth),
        "total_flagged": len(flagged),
    }


# ---------- Notification (stub) ----------

def notify_strategist(summary: str) -> None:
    """Production: gửi Slack/email với link approve. Local: in ra console."""
    print("\n" + "=" * 60)
    print("NOTIFY STRATEGIST — pattern cần review:")
    print(summary)
    print("=" * 60 + "\n")
