"""Sinh mock fraud data và load vào DuckDB cho local dev.

Thay file này bằng warehouse thật khi lên production — chỉ cần
warehouse_query() trong tools.py trỏ tới BigQuery/Spark thay vì DuckDB.
"""
from __future__ import annotations

import random
from pathlib import Path

import duckdb
import pandas as pd

DATA_DIR = Path(__file__).parent.parent / "data"
PARQUET_PATH = DATA_DIR / "transactions.parquet"


def generate_mock_transactions(n: int = 5000, seed: int = 42) -> pd.DataFrame:
    """Sinh transactions với một fraud pattern ẩn được cài sẵn.

    Pattern ẩn: device_id dùng lại > 3 lần + amount > 5,000,000 VND
    + giờ giao dịch 0h-5h sáng  ->  khả năng cao là fraud.
    """
    random.seed(seed)
    rows = []
    devices = [f"dev_{i:04d}" for i in range(800)]
    dirty_devices = set(random.sample(devices, 25))

    for i in range(n):
        # dirty device xuất hiện với tần suất cao hơn hẳn (reuse nhiều)
        is_dirty_device = random.random() < 0.18
        device = random.choice(list(dirty_devices)) if is_dirty_device else random.choice(devices)
        amount = random.choice([50_000, 200_000, 800_000, 2_000_000, 6_500_000, 12_000_000])
        hour = random.randint(0, 23)

        # ground truth: device bẩn (reuse nhiều) + amount cao + đêm
        on_pattern = device in dirty_devices and amount > 5_000_000 and hour < 5
        is_fraud = on_pattern and random.random() < 0.92
        if not is_fraud and random.random() < 0.002:
            is_fraud = True

        rows.append({
            "txn_id": f"txn_{i:06d}",
            "device_id": device,
            "amount": amount,
            "hour": hour,
            "merchant_cat": random.choice(["food", "ecom", "transfer", "topup", "gaming"]),
            "is_fraud": int(is_fraud),  # ground truth label
        })

    return pd.DataFrame(rows)


def ensure_data() -> str:
    """Đảm bảo có parquet file. Trả về path."""
    DATA_DIR.mkdir(exist_ok=True)
    if not PARQUET_PATH.exists():
        df = generate_mock_transactions()
        df.to_parquet(PARQUET_PATH, index=False)
    return str(PARQUET_PATH)


def query(sql: str) -> pd.DataFrame:
    """Chạy SQL trên parquet bằng DuckDB. Table name = 'transactions'."""
    path = ensure_data()
    con = duckdb.connect(":memory:")
    con.execute(f"CREATE VIEW transactions AS SELECT * FROM read_parquet('{path}')")
    try:
        return con.execute(sql).fetchdf()
    finally:
        con.close()


if __name__ == "__main__":
    df = generate_mock_transactions()
    print(f"Generated {len(df)} txns, {df.is_fraud.sum()} fraud "
          f"({df.is_fraud.mean()*100:.1f}%)")
    ensure_data()
    print(f"Saved to {PARQUET_PATH}")
