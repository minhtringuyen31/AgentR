"""AgentState và các structured model.

State là single source of truth, được LangGraph persist qua checkpointer
ở mỗi step. Mỗi node nhận state, trả về partial update (dict các field thay đổi).
"""
from __future__ import annotations

from typing import Annotated, Literal, Optional, TypedDict
from operator import add

from pydantic import BaseModel, Field


# ---------- Structured payloads (đi vào/ra giữa các node) ----------

class FraudContext(BaseModel):
    """Output của ingest_node — kết quả parse từ email/post-mortem."""
    case_ids: list[str] = Field(default_factory=list)
    fraud_type: str = "unknown"
    severity: Literal["low", "medium", "high", "critical"] = "medium"
    time_hint: Optional[str] = None  # ví dụ: "last 90 days"
    raw_summary: str = ""


class PatternHypothesis(BaseModel):
    """Output của hypothesis_node — một giả thuyết pattern fraud."""
    description: str
    signal_columns: list[str] = Field(default_factory=list)
    rationale: str = ""
    expected_precision: float = 0.0
    expected_recall: float = 0.0
    # SQL hint fields (mock dùng để sinh query; LLM thật bỏ qua, tự suy từ description)
    reuse: Optional[int] = Field(default=None, alias="_reuse")
    amount: Optional[int] = Field(default=None, alias="_amount")
    hour: Optional[int] = Field(default=None, alias="_hour")

    model_config = {"populate_by_name": True}


class MetricsResult(BaseModel):
    """Output của metrics_node."""
    precision: float = 0.0
    recall: float = 0.0
    f1: float = 0.0
    hit_count: int = 0
    total_fraud: int = 0
    total_flagged: int = 0


class ThresholdConfig(BaseModel):
    """Ngưỡng business — strategist set lúc trigger run."""
    min_precision: float = 0.80
    min_recall: float = 0.60
    max_iterations: int = 6


class PatternReport(BaseModel):
    """Payload đưa cho human review + output cuối."""
    pattern: PatternHypothesis
    sql: str
    metrics: MetricsResult
    iteration_count: int
    iteration_history: list[dict] = Field(default_factory=list)
    recommendation: str = ""


# ---------- AgentState ----------

class AgentState(TypedDict, total=False):
    # ingest
    source_type: Literal["email", "postmortem"]
    raw_input: str
    fraud_context: dict          # FraudContext.model_dump()
    case_ids: list[str]

    # data
    data_ref: str                # path tới parquet / table name
    data_schema: dict            # {col: dtype}
    sample_rows: list[dict]
    threshold_config: dict       # ThresholdConfig.model_dump()

    # pattern discovery loop
    hypotheses: Annotated[list[dict], add]   # append mỗi iteration
    current_pattern: dict        # PatternHypothesis.model_dump()
    current_sql: str
    matched_case_ids: list[str]
    metrics: dict                # MetricsResult.model_dump()
    iteration_count: int

    # decision + human
    route: Literal["pass", "retry", "escalate"]
    approved_by: Optional[str]
    review_decision: Optional[Literal["approve", "reject"]]

    # output
    final_report: dict           # PatternReport.model_dump()

    # meta
    run_id: str
