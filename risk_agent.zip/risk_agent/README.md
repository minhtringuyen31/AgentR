# Risk Analysis Agent

Agent phân tích fraud pattern bằng LangGraph. Nhận trigger (email / post-mortem),
fetch historical data, lặp tìm pattern đến khi đạt ngưỡng precision/recall,
pause chờ strategist approve, rồi output policy rule.

Skeleton này chạy được ngay với **mock data + DuckDB**, không cần API key hay
warehouse thật.

## Chạy thử

```bash
pip install -r requirements.txt
python -m risk_agent.mock_data    # sinh data/transactions.parquet
python -m risk_agent.main         # chạy agent end-to-end (CLI)
```

## Chạy như API service

```bash
uvicorn risk_agent.service:app --reload
# docs tự động: http://localhost:8000/docs
python -m risk_agent.test_service   # test E2E qua TestClient
```

Luồng API:

| Method | Endpoint | Vai trò |
|--------|----------|---------|
| POST | `/runs` | Tạo run từ trigger, chạy nền đến interrupt. Trả `run_id`, status=`running` |
| GET | `/runs/{run_id}` | Trạng thái + report. status: running / awaiting_review / completed |
| POST | `/runs/{run_id}/review` | `{decision: approve\|reject, reviewer}` → resume agent |
| GET | `/runs` | List run_id |
| POST | `/triggers/email` | Webhook cho email listener |
| POST | `/triggers/postmortem` | Webhook cho post-mortem DB event |

Client điển hình: POST `/runs` → poll GET `/runs/{id}` đến khi `awaiting_review`
→ hiện report cho strategist → POST `/review` → poll đến `completed`.

Checkpointer dùng `SqliteSaver` (`checkpoints.db`) nên run sống qua restart service.
Background task chạy loop pattern discovery; interrupt tự pause tại human review.

Output minh hoạ loop pattern discovery, interrupt tại human review, resume sau approve.

## Cấu trúc

| File | Vai trò |
|------|---------|
| `state.py` | `AgentState` (TypedDict) + Pydantic models cho payload giữa các node |
| `mock_data.py` | Sinh fraud data + DuckDB query — **thay bằng warehouse thật ở prod** |
| `llm.py` | LLM abstraction. `MockLLM` (mặc định) / `ClaudeLLM` (real) |
| `tools.py` | Tools deterministic: `warehouse_query`, `compute_metrics`, SQL safety |
| `nodes.py` | 8 node functions: ingest → fetch → hypothesis → sql_gen → metrics → router → human_review → policy_output |
| `graph.py` | Lắp graph + checkpointer + `interrupt_before` |
| `service.py` | FastAPI service: trigger / status / review endpoints, SqliteSaver |
| `main.py` | CLI entry point, demo interrupt/resume |
| `test_service.py` | Test E2E service qua TestClient |

## Loop logic

```
START → ingest → fetch_data → hypothesis → sql_gen → metrics → router
router --retry--→ hypothesis              (chưa đạt threshold, iterate)
router --escalate--→ human_review         (vượt max_iterations)
router --pass--→ human_review             (đạt threshold)
human_review → [INTERRUPT, chờ strategist] → policy_output → END
```

## Chuyển sang production

Mỗi phần là một điểm thay thế độc lập, signature giữ nguyên:

1. **LLM thật**: `pip install anthropic`, set `ANTHROPIC_API_KEY` và `USE_REAL_LLM=1`.
   `hypothesis_node` đã bật extended thinking.
2. **Warehouse thật**: sửa `tools.warehouse_query()` trỏ BigQuery/Spark thay DuckDB.
   `get_schema_and_sample()` lấy schema thật.
3. **Ground truth**: sửa `compute_metrics()` join với post-mortem DB confirmed fraud
   thay vì cột `is_fraud`.
4. **Checkpointer**: đổi `MemorySaver()` → `PostgresSaver` trong `graph.py` cho persistent.
5. **Trigger thật**: thêm IMAP listener / DB CDC consumer gọi `app.stream(init, config)`.
6. **Review UI**: Streamlit đọc `app.get_state()`, hiện report, nút approve/reject gọi
   `app.update_state()` rồi `app.stream(None, config)` để resume.
7. **SQL safety**: `validate_sql()` mới chặn lệnh ghi cơ bản. Prod nên thêm
   EXPLAIN cost check, row limit, query timeout.

## Điểm cần quyết định trước khi scale

- Format `RuleJSON` ở `policy_output_node` — contract với config-service.
- Ground truth fraud labels nằm ở đâu, có sẵn lúc chạy hay cần confirm thủ công.
- Strategist nhận notification qua kênh nào (Slack/email) và resume qua UI nào.
